use hud::{Console, ErrorReport};
use std::io;
use std::path::Path;

fn main() {
    let path = Path::new("/etc/hud/config.toml");
    let os_error = io::Error::from_raw_os_error(2);
    let report = ErrorReport::new("could not read config")
        .cause(os_error.to_string())
        .cause(format!("path: {}", path.display()))
        .hint("run again with --verbose for details");
    Console::stdout().print(&report);
}
