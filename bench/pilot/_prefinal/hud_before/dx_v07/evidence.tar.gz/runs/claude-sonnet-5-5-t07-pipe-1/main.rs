use hud::{Column, Console, Justify, Table};

fn main() {
    let data = [
        ("clap", "4.5.40", "12,400,000", "ok"),
        ("serde", "1.0.219", "98,300,000", "ok"),
        ("tokio", "1.46.1", "45,100,000", "ok"),
        ("ratatui", "0.29.0", "2,310,000", "warn"),
        ("syn", "2.0.104", "87,000,000", "fail"),
    ];

    let mut table = Table::new()
        .title("Build report")
        .column("[bold cyan]Crate[/]")
        .column("[bold cyan]Version[/]")
        .column(Column::new("[bold cyan]Downloads[/]").justify(Justify::Right))
        .column("[bold cyan]Status[/]");

    for (name, version, downloads, status) in data {
        let color = match status {
            "ok" => "green",
            "warn" => "yellow",
            _ => "red",
        };
        table.add_row([
            name.to_string(),
            version.to_string(),
            downloads.to_string(),
            format!("[{color}]{status}[/]"),
        ]);
    }

    Console::stdout().print(&table);
}
