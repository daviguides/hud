use hud::{Console, Tree};

fn main() {
    let src = Tree::new("src/")
        .child("lib.rs")
        .child("console.rs")
        .child("width.rs");
    let tests = Tree::new("tests/").child("golden.rs");
    let tree = Tree::new("hud/")
        .child(src)
        .child(tests)
        .child("Cargo.toml")
        .child("README.md");
    Console::stdout().print(&tree);
}
