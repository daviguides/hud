use hud::{Console, Panel};

const NOTICE: &str = "hud renders terminal output that reads at a glance. Tables, panels, trees and progress share one width model, so wide characters such as 日本語 and emoji keep every border aligned on any terminal.";

fn main() {
    Console::stdout().print(&Panel::new(NOTICE).title("Notice"));
}
