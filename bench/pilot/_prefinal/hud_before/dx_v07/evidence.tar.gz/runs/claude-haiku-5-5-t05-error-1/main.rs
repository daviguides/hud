use hud::{Console, ErrorReport};
use std::io;

fn main() {
    let error = io::Error::from_raw_os_error(2);
    let report = ErrorReport::new("could not read config")
        .cause(error.to_string())
        .cause("path: /etc/hud/config.toml")
        .hint("run again with --verbose for details");
    Console::stdout().print(&report);
}
