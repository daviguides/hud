use hud::{Color, Console, Style, Text};

fn main() {
    let console = Console::stdout();

    let mut line1 = Text::default();
    line1.append("Deploy", Style::new().bold());
    line1.append(" ", Style::new());
    line1.append("ok", Style::new().color(Color::GREEN));
    line1.append(" in ", Style::new());
    line1.append("3.2s", Style::new().color(Color::YELLOW).italic());
    console.print(&line1);

    let mut line2 = Text::default();
    line2.append("outer ", Style::new().bold());
    line2.append("inner ", Style::new().bold().italic());
    line2.append("deep", Style::new().bold().italic().underline());
    line2.append(" outer", Style::new().bold());
    console.print(&line2);

    let mut line3 = Text::default();
    line3.append(" FAIL ", Style::new().color(Color::RED).bgcolor(Color::WHITE).bold());
    line3.append(" ", Style::new());
    line3.append("retry", Style::new().strike());
    line3.append(" in 5s", Style::new());
    console.print(&line3);
}
