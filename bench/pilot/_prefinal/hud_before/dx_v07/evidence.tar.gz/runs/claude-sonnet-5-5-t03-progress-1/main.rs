use hud::{BarColumn, MofNCompleteColumn, Progress, TaskProgressColumn, TextColumn};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(30))
        .column(TaskProgressColumn::new())
        .column(MofNCompleteColumn::new())
        .build();

    let tasks = [
        progress.add_task("fetch index", 3),
        progress.add_task("download crates", 120),
        progress.add_task("verify", 12),
    ];

    for _ in 0..120 {
        for task in &tasks {
            if !task.is_finished() {
                task.advance(1);
            }
        }
    }

    progress.refresh();
    progress.finish();
}
