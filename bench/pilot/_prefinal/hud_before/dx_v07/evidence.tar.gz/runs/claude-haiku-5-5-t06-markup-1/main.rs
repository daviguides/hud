use hud::{Color, Console, Style, Text};

fn line(parts: &[(&str, Style)]) -> Text {
    let mut text = Text::new("");
    for (piece, style) in parts {
        text.append(piece, style.clone());
    }
    text
}

fn main() {
    let console = Console::stdout();
    let plain = Style::new();
    let bold = Style::new().bold();

    console.print(&line(&[
        ("Deploy", bold.clone()),
        (" ", plain.clone()),
        ("ok", Style::new().color(Color::GREEN)),
        (" in ", plain.clone()),
        ("3.2s", Style::new().italic().color(Color::YELLOW)),
    ]));

    console.print(&line(&[
        ("outer ", bold.clone()),
        ("inner ", bold.clone().italic()),
        ("deep", bold.clone().italic().underline()),
        (" outer", bold.clone()),
    ]));

    console.print(&line(&[
        (" FAIL ", bold.clone().color(Color::RED).bgcolor(Color::WHITE)),
        (" ", plain.clone()),
        ("retry", Style::new().strike()),
        (" in 5s", plain.clone()),
    ]));
}
