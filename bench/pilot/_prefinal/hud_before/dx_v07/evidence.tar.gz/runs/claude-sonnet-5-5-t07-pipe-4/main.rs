use hud::{Column, Console, Justify, Table};

fn main() {
    let status = |s: &str| match s {
        "ok" => "[green]ok[/]",
        "warn" => "[yellow]warn[/]",
        _ => "[red]fail[/]",
    };
    let header = |h: &str| format!("[bold cyan]{h}[/]");

    let mut table = Table::new()
        .title("Build report")
        .column(header("Crate"))
        .column(header("Version"))
        .column(Column::new(header("Downloads")).justify(Justify::Right))
        .column(header("Status"));

    let rows = [
        ("clap", "4.5.40", "12,400,000", "ok"),
        ("serde", "1.0.219", "98,300,000", "ok"),
        ("tokio", "1.46.1", "45,100,000", "ok"),
        ("ratatui", "0.29.0", "2,310,000", "warn"),
        ("syn", "2.0.104", "87,000,000", "fail"),
    ];
    for (name, version, downloads, st) in rows {
        table.add_row([name, version, downloads, status(st)]);
    }

    Console::stdout().print(&table);
}
