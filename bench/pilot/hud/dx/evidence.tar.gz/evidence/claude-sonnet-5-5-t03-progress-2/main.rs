use hud::{BarColumn, MofNCompleteColumn, Progress, TaskProgressColumn, TextColumn};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(30))
        .column(TaskProgressColumn::new())
        .column(MofNCompleteColumn::new())
        .auto_refresh(false)
        .build();

    let tasks = [
        (progress.add_task("fetch index", 3), 3u64),
        (progress.add_task("download crates", 120), 120),
        (progress.add_task("verify", 12), 12),
    ];

    for step in 0..120u64 {
        for (task, total) in &tasks {
            if step < *total {
                task.advance(1);
            }
        }
    }

    progress.refresh();
    progress.finish();
}
