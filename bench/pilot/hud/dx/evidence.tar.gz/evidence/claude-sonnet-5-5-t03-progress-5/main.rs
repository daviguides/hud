use hud::{BarColumn, MofNCompleteColumn, Progress, TaskProgressColumn, TextColumn};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(30))
        .column(TaskProgressColumn::new())
        .column(MofNCompleteColumn::new())
        .build();

    let tasks = [
        (progress.add_task("fetch index", 3), 3u64),
        (progress.add_task("download crates", 120), 120),
        (progress.add_task("verify", 12), 12),
    ];

    let mut done = [0u64; 3];
    while done.iter().zip(tasks.iter()).any(|(d, (_, total))| d < total) {
        for (i, (task, total)) in tasks.iter().enumerate() {
            if done[i] < *total {
                progress.advance(task, 1);
                done[i] += 1;
            }
        }
        progress.refresh();
    }

    progress.finish();
}
