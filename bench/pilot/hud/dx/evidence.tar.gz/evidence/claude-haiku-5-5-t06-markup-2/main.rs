use hud::{Console, Style, Text};

fn style(definition: &str) -> Style {
    Style::parse(definition).expect("valid style")
}

fn main() {
    let console = Console::stdout();

    let mut line1 = Text::default();
    line1.append("Deploy", style("bold"));
    line1.append(" ", Style::new());
    line1.append("ok", style("green"));
    line1.append(" in ", Style::new());
    line1.append("3.2s", style("italic yellow"));
    console.print(&line1);

    let mut line2 = Text::default();
    line2.append("outer ", style("bold"));
    line2.append("inner ", style("bold italic"));
    line2.append("deep", style("bold italic underline"));
    line2.append(" outer", style("bold"));
    console.print(&line2);

    let mut line3 = Text::default();
    line3.append(" FAIL ", style("bold red on white"));
    line3.append(" ", Style::new());
    line3.append("retry", style("strike"));
    line3.append(" in 5s", Style::new());
    console.print(&line3);
}
