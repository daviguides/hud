use hud::{Console, Tree};

fn main() {
    let mut src = Tree::new("src/");
    src.add("lib.rs");
    src.add("console.rs");
    src.add("width.rs");

    let mut tests = Tree::new("tests/");
    tests.add("golden.rs");

    let tree = Tree::new("hud/")
        .child(src)
        .child(tests)
        .child("Cargo.toml")
        .child("README.md");

    Console::stdout().print(&tree);
}
