use std::{error::Error, fmt, io};

#[derive(Debug)]
struct ConfigError {
    source: io::Error,
}

impl fmt::Display for ConfigError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("could not read config")
    }
}

impl Error for ConfigError {
    fn source(&self) -> Option<&(dyn Error + 'static)> {
        Some(&self.source)
    }
}

fn main() {
    let error = ConfigError {
        source: io::Error::from_raw_os_error(2),
    };
    let report = hud::ErrorReport::from_error(&error)
        .cause("path: /etc/hud/config.toml")
        .hint("run again with --verbose for details");
    hud::Console::stdout().print(&report);
}
