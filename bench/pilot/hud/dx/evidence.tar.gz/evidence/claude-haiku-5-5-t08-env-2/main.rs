use hud::{Color, Console, Style, Text};

fn main() {
    let mut line = Text::new("");
    line.append("error", Style::new().bold().color(Color::RED));
    line.append(" ", Style::new());
    line.append("ok", Style::new().color(Color::GREEN));
    line.append(" ", Style::new());
    line.append("plain", Style::new());
    Console::stdout().print(&line);
}
