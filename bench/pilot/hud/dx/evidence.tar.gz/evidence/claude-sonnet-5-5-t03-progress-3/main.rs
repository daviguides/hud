use hud::{BarColumn, MofNCompleteColumn, Progress, TaskProgressColumn, TextColumn};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(30))
        .column(TaskProgressColumn::new())
        .column(MofNCompleteColumn::new())
        .build();

    let fetch = progress.add_task("fetch index", 3);
    let download = progress.add_task("download crates", 120);
    let verify = progress.add_task("verify", 12);

    for _ in 0..120 {
        download.advance(1);
        fetch.advance(if download_done_fetch() { 0 } else { 0 });
    }
    for _ in 0..3 {
        fetch.advance(1);
    }
    for _ in 0..12 {
        verify.advance(1);
    }

    progress.finish();
}

fn download_done_fetch() -> bool {
    true
}
