use hud::{Color, Console, Style, Text};

fn main() {
    let mut text = Text::new(String::new());
    text.append("error", Style::new().bold().color(Color::RED));
    text.append(" ", Style::new());
    text.append("ok", Style::new().color(Color::GREEN));
    text.append(" plain", Style::new());
    Console::stdout().print(&text);
}
