use hud::{Color, Console, Style, Text};

fn line(parts: &[(&str, Style)]) -> Text {
    let mut text = Text::new("");
    for (fragment, style) in parts {
        text.append(fragment, style.clone());
    }
    text
}

fn main() {
    let console = Console::stdout();

    console.print(&line(&[
        ("Deploy", Style::new().bold()),
        (" ", Style::new()),
        ("ok", Style::new().color(Color::GREEN)),
        (" in ", Style::new()),
        ("3.2s", Style::new().color(Color::YELLOW).italic()),
    ]));

    console.print(&line(&[
        ("outer ", Style::new().bold()),
        ("inner ", Style::new().bold().italic()),
        ("deep", Style::new().bold().italic().underline()),
        (" outer", Style::new().bold()),
    ]));

    console.print(&line(&[
        (" FAIL ", Style::new().color(Color::RED).bgcolor(Color::WHITE).bold()),
        (" ", Style::new()),
        ("retry", Style::new().strike()),
        (" in 5s", Style::new()),
    ]));
}
