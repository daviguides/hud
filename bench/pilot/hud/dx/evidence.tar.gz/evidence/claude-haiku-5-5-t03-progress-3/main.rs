use hud::{BarColumn, MofNCompleteColumn, Progress, TaskProgressColumn, TextColumn};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(30))
        .column(TaskProgressColumn::new())
        .column(MofNCompleteColumn::new())
        .build();

    let fetch = progress.add_task("fetch index", 3);
    let download = progress.add_task("download crates", 120);
    let verify = progress.add_task("verify", 12);
    let tasks = [&fetch, &download, &verify];

    while !tasks.iter().all(|task| task.is_finished()) {
        for task in &tasks {
            if !task.is_finished() {
                task.advance(1);
            }
        }
    }

    progress.finish();
}
