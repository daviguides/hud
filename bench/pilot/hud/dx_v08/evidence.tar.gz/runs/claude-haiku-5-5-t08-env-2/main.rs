use hud::Console;

fn main() {
    Console::stdout().print("[bold red]error[/] [green]ok[/] plain");
}
