use hud::{BarColumn, Console, Layout, Panel, Progress, Table, TaskProgressColumn, TextColumn};

fn main() {
    let console = Console::stdout();

    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(20))
        .column(TaskProgressColumn::new())
        .disable(true)
        .build();
    let build = progress.add_task("build", 10);
    build.advance(10);
    let test = progress.add_task("test", 40);
    test.advance(40);

    let table = Table::new()
        .column("Crate")
        .column("Version")
        .row(["hud", "0.1.0"])
        .row(["hud-width", "0.1.0"]);
    let status = Panel::new("All checks passed").title("Status");
    let progress_text = console.render_to_plain(&progress);

    let layout = Layout::column([
        Layout::row([Layout::new(table), Layout::new(status)]),
        Layout::new(progress_text).size(4),
    ]);
    console.print(&layout);
}
