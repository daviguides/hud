fn main() {
    hud::println!("[bold]Deploy[/] [green]ok[/] in [italic yellow]3.2s[/]");
    hud::println!("[bold]outer [italic]inner [underline]deep[/underline][/italic] outer[/bold]");
    hud::println!("[bold red on white] FAIL [/] [strike]retry[/strike] in 5s");
}
