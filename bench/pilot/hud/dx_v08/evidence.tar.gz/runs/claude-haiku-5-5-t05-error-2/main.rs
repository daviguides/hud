use std::io;

use hud::{Console, ErrorReport};

fn main() {
    let cause = io::Error::from_raw_os_error(2).to_string();
    let report = ErrorReport::new("could not read config")
        .cause(cause)
        .cause("path: /etc/hud/config.toml")
        .hint("run again with --verbose for details");
    Console::stdout().print(&report);
}
