use hud::{Column, Console, Justify, Table};

fn main() {
    let table = Table::new()
        .column(Column::new("Name").justify(Justify::Left))
        .column(Column::new("Count").justify(Justify::Right))
        .row(["api", "12"])
        .row(["cli", "7"]);
    Console::stdout().print(&table);
}
