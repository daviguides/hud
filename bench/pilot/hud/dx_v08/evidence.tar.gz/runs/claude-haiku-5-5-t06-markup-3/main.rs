fn main() {
    hud::println!("[bold]Deploy[/] [green]ok[/] in [yellow italic]3.2s[/]");
    hud::println!("[bold]outer [italic]inner [underline]deep[/][/] outer[/]");
    hud::println!("[bold red on white] FAIL [/] [strike]retry[/] in 5s");
}
