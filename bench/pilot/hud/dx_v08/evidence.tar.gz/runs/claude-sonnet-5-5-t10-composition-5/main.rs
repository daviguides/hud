use hud::{
    BarColumn, Body, Column, Console, Layout, Panel, Progress, Table, TaskProgressColumn,
    TextColumn,
};

fn main() {
    let progress = Progress::builder()
        .disable(true)
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(20))
        .column(TaskProgressColumn::new())
        .build();
    let build = progress.add_task("build", 10);
    build.advance(10);
    let test = progress.add_task("test", 40);
    test.advance(40);

    let table = Table::new()
        .column(Column::new("Crate"))
        .column(Column::new("Version"))
        .row(["hud", "0.1.0"])
        .row(["hud-width", "0.1.0"]);

    let layout = Layout::column([
        Layout::row([
            Layout::new(table),
            Layout::new(Panel::new("All checks passed").title("Status")),
        ]),
        Layout::new(Body::new(progress)).size(4),
    ]);

    let console = Console::stdout();
    console.print(&layout);
}
