use hud::{BarColumn, MofNCompleteColumn, Progress, TaskProgressColumn, TextColumn};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(30))
        .column(TaskProgressColumn::new())
        .column(MofNCompleteColumn::new())
        .build();

    let index = progress.add_task("fetch index", 3);
    let crates = progress.add_task("download crates", 120);
    let verify = progress.add_task("verify", 12);

    for _ in 0..120 {
        if !index.is_finished() {
            index.advance(1);
        }
        crates.advance(1);
        if !verify.is_finished() {
            verify.advance(1);
        }
        progress.refresh();
    }

    progress.finish();
}
