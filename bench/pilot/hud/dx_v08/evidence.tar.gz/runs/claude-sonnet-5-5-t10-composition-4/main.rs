use hud::{
    BarColumn, Body, Console, Layout, Panel, Progress, Table, TaskProgressColumn, TextColumn,
};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(20))
        .column(TaskProgressColumn::new())
        .disable(true)
        .build();
    let build = progress.add_task("build", 10);
    let test = progress.add_task("test", 40);
    progress.advance(&build, 10);
    progress.advance(&test, 40);

    let table = Table::new()
        .column("Crate")
        .column("Version")
        .row(["hud", "0.1.0"])
        .row(["hud-width", "0.1.0"]);
    let panel = Panel::new("All checks passed").title("Status");

    let layout = Layout::column([
        Layout::row([Layout::new(table), Layout::new(panel)]),
        Layout::new(Body::new(progress)).size(4),
    ]);

    Console::stdout().print(&layout);
}
