use hud::{BarColumn, MofNCompleteColumn, Progress, TaskProgressColumn, TextColumn};

fn main() {
    let progress = Progress::builder()
        .column(TextColumn::new("{task.description}"))
        .column(BarColumn::new().bar_width(30))
        .column(TaskProgressColumn::new())
        .column(MofNCompleteColumn::new())
        .build();

    let fetch = progress.add_task("fetch index", 3);
    let download = progress.add_task("download crates", 120);
    let verify = progress.add_task("verify", 12);

    for step in 0..120u64 {
        download.advance(1);
        if step % 40 == 39 {
            fetch.advance(1);
        }
        if step % 10 == 9 {
            verify.advance(1);
        }
    }

    progress.refresh();
    progress.finish();
}
