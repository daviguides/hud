use hud::Console;

fn main() {
    let console = Console::stdout();
    console.print("[bold]Deploy[/] [green]ok[/] in [italic yellow]3.2s[/]");
    console.print("[bold]outer [italic]inner [underline]deep[/][/] outer[/]");
    console.print("[bold red on white] FAIL [/] [strike]retry[/] in 5s");
}
